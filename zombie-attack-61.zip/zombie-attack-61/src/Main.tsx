import React from 'react';
import {AbsoluteFill, Audio, Series, staticFile, interpolate} from 'remotion';
import {fontFamily} from './font';
import {FLAGS, TOTAL} from './data';
import {Grade, Grain, Flash, clamp} from './components/Fx';
import {Scene1} from './scenes/Scene1';
import {Scene2} from './scenes/Scene2';
import {Scene3} from './scenes/Scene3';
import {Scene4} from './scenes/Scene4';
import {Scene5} from './scenes/Scene5';

// เวลา (เฟรม @30fps): 12s / 13s / 25s / 20s / 20s = 90s
const S = [360, 390, 750, 600, 600];
const scenes = [Scene1, Scene2, Scene3, Scene4, Scene5];

export const Main: React.FC = () => (
  <AbsoluteFill style={{background: '#000', fontFamily}}>
    <Series>
      {scenes.map((Sc, i) => (
        <Series.Sequence key={i} durationInFrames={S[i]}>
          <Sc />
          {i > 0 && <Flash len={8} color={i === 4 ? '#9fb8ff' : '#ff2233'} />}
        </Series.Sequence>
      ))}
    </Series>
    <Grade />
    <Grain />
    {FLAGS.audio && (
      <Audio
        src={staticFile('audio/bgm.wav')}
        volume={(f) => interpolate(f, [0, 30, TOTAL - 60, TOTAL], [0, 0.45, 0.45, 0], clamp)}
      />
    )}
  </AbsoluteFill>
);
