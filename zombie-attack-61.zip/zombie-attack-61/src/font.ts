import {loadFont} from '@remotion/google-fonts/Kanit';
export const {fontFamily} = loadFont('normal', {weights: ['400', '700', '900'], subsets: ['thai', 'latin']});
