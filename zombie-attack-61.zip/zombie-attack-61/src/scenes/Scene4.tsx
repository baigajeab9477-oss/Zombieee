import React from 'react';
import {AbsoluteFill, random, useCurrentFrame, interpolate} from 'remotion';
import {CHARS} from '../data';
import {Person} from '../components/Person';
import {Classroom, Shake, Glitch, clamp} from '../components/Fx';
import {Subs, Sfx, Line} from '../components/Media';

const lines: Line[] = [
  {id: 's4-1', from: 10, to: 80, who: 'ภูผา', text: 'ทุกคน! วิ่งไปทางนี้!'},
  {id: 's4-2', from: 88, to: 170, who: 'ไกด์', text: 'ตามเรามา เรารู้ทาง!'},
  {id: 's4-3', from: 300, to: 375, who: 'ทุกคน', text: 'ไกด์!!!!', big: true, color: '#ff4d5a'},
  {id: 's4-4', from: 385, to: 450, who: 'นักเรียน', text: 'ซอมบี้มาแล้ว! ประตูอยู่ไหน!?'},
  {id: 's4-5', from: 455, to: 520, who: 'นักเรียน', text: 'ใครก็ได้ หาทางออกที!'},
  {id: 's4-6', from: 525, to: 596, who: 'ทุกคน', text: 'วิ่งงงงง!!!', big: true},
];
const signs = ['ตึก A', 'ห้องน้ำ', 'โรงอาหาร', 'ห้องสมุด', 'ตึก B'];

const Run: React.FC = () => {
  const f = useCurrentFrame();
  const others = CHARS.map((_, i) => i).filter((i) => i !== 4);
  return (
    <AbsoluteFill>
      <Classroom alert />
      {[0, 1, 2, 3, 4, 5].map((k) => (
        <div key={k} style={{position: 'absolute', top: 360 + k * 70, left: ((k * 500 - f * 40) % 1400) - 200, width: 400, height: 6, background: 'rgba(255,255,255,.25)'}} />
      ))}
      <div style={{position: 'absolute', left: 340 + Math.sin(f / 6) * 20, top: 400}}>
        <Person i={4} h={330} />
        <div style={{textAlign: 'center', fontSize: 60}}>📍</div>
      </div>
      {others.map((i, n) => {
        const col = n % 6, row = Math.floor(n / 6);
        const y = 880 + row * 165 - Math.abs(Math.sin(f / 3 + i)) * 16;
        return (
          <div key={i} style={{position: 'absolute', left: 50 + col * 165 + Math.sin(f / 10 + i) * 8, top: y}}>
            <Person i={i} h={140} />
          </div>
        );
      })}
    </AbsoluteFill>
  );
};

const Montage: React.FC = () => {
  const f = useCurrentFrame();
  const door = f >= 270;
  const k = Math.min(4, Math.floor((f - 180) / 18));
  return (
    <AbsoluteFill>
      <Classroom alert />
      <div style={{position: 'absolute', top: 520, width: '100%', textAlign: 'center', color: '#fff', fontWeight: 900, fontSize: door ? 170 : 150, textShadow: '0 0 30px #e11'}}>
        {door ? 'ม.6/1' : signs[k]}
      </div>
      <div style={{position: 'absolute', top: 760, width: '100%', textAlign: 'center', fontSize: 160}}>{door ? '😱' : '😵‍💫'}</div>
      <div style={{position: 'absolute', left: 390, top: 1000}}><Person i={4} h={420} /></div>
      {door && <div style={{position: 'absolute', top: 1450, width: '100%', textAlign: 'center', color: '#ff4d5a', fontWeight: 900, fontSize: 64}}>กลับมาที่เดิมอีกแล้ว</div>}
    </AbsoluteFill>
  );
};

const Chaos: React.FC = () => {
  const f = useCurrentFrame();
  const ppl = CHARS.map((_, i) => ({
    i,
    x: 450 + Math.sin(f / (9 + random(`a${i}`) * 8) + i * 2) * 400,
    y: 560 + (Math.cos(f / (11 + random(`b${i}`) * 9) + i) * 0.5 + 0.5) * 900,
    h: 110 + random(`c${i}`) * 30,
  })).sort((a, b) => a.y - b.y);
  const n = Math.floor(interpolate(f, [300, 520], [2, 10], clamp));
  return (
    <AbsoluteFill>
      <Classroom alert />
      {Array.from({length: n}, (_, j) => {
        const tx = ((j * 97 + 120) % 800) + 60;
        const x = Math.max(tx, 1300 - (f - 300) * (1.2 + j * 0.12));
        return (
          <div key={j} style={{position: 'absolute', left: x, top: 450 + ((j * 173) % 700)}}>
            <Person i={j + 9} h={250} zombie flip />
          </div>
        );
      })}
      {ppl.map((p) => (
        <div key={p.i} style={{position: 'absolute', left: p.x, top: p.y}}>
          <Person i={p.i} h={p.h} />
        </div>
      ))}
    </AbsoluteFill>
  );
};

export const Scene4: React.FC = () => {
  const f = useCurrentFrame();
  const body = f < 180 ? <Run /> : f < 300 ? <Montage /> : <Chaos />;
  const amp = f >= 300 && f < 340 ? 16 : f >= 340 ? 7 : f >= 180 ? 4 : 3;
  const zoom = f >= 300 && f < 340 ? interpolate(f, [300, 340], [1.25, 1], clamp) : 1;
  return (
    <AbsoluteFill>
      <Shake amp={amp}>
        <AbsoluteFill style={{transform: `scale(${zoom})`}}>{body}</AbsoluteFill>
      </Shake>
      <Glitch on={f >= 180 && f < 270 && (f - 180) % 18 < 4} />
      <Subs lines={lines} />
      <Sfx name="whoosh" at={10} vol={0.6} />
      <Sfx name="whoosh" at={88} vol={0.6} />
      {[0, 1, 2, 3, 4].map((k) => <Sfx key={k} name="glitch" at={180 + k * 18} vol={0.5} />)}
      <Sfx name="womp" at={300} />
      <Sfx name="groan" at={330} vol={0.6} />
      <Sfx name="scream" at={400} vol={0.5} />
      <Sfx name="scream" at={500} vol={0.5} />
    </AbsoluteFill>
  );
};
