import React from 'react';
import {AbsoluteFill, useCurrentFrame, interpolate} from 'remotion';
import {CHARS} from '../data';
import {Person} from '../components/Person';
import {Classroom, Shake, Glitch, clamp} from '../components/Fx';
import {Subs, Sfx, Line} from '../components/Media';

const lines: Line[] = [
  {id: 's5-1', from: 50, to: 140, who: 'ภูมิ', text: 'ในที่สุด… เราก็รอด'},
  {id: 's5-2', from: 150, to: 290, who: 'เสียงประกาศ', text: 'ขอแจ้งนักเรียน ม.6/1 ทุกคน ขณะนี้โรงเรียนได้ประกาศปิดเรียนเป็นเวลา 7 วัน เนื่องจากเหตุการณ์ฉุกเฉิน'},
  {id: 's5-3', from: 350, to: 410, who: 'การ์ตูน', text: 'แล้วการบ้านล่ะ?'},
  {id: 's5-4', from: 410, to: 480, who: 'ทุกคน', text: 'การบ้านนนนน!!!', big: true, color: '#ff4d5a'},
];

export const Scene5: React.FC = () => {
  const f = useCurrentFrame();
  const zoom = f < 470 ? 1.9 : interpolate(f, [470, 500], [1.9, 1], clamp);
  const relief = f >= 60 && f < 150;
  const shout = f >= 410 && f < 480;
  const amp = shout ? 12 : f >= 470 && f < 500 ? 5 : 0;
  const black = f >= 515;
  const t = interpolate(f, [530, 550], [0, 1], clamp);
  return (
    <AbsoluteFill style={{background: '#000'}}>
      {!black && (
        <Shake amp={amp}>
          <Classroom calm />
          <div style={{position: 'absolute', top: 90, width: '100%', textAlign: 'center', color: '#9fe8c0', fontWeight: 900, fontSize: 64}}>จุดปลอดภัย ✅</div>
          <AbsoluteFill style={{transform: `scale(${zoom})`, transformOrigin: '50% 85%'}}>
            <div style={{position: 'absolute', left: 540 - 250 + Math.sin(f / 20) * 6, top: 330, opacity: f >= 485 ? 1 : 0}}>
              <Person i={12} h={780} zombie />
            </div>
            {CHARS.map((c, i) => {
              const col = i % 7, row = Math.floor(i / 7);
              const sag = relief ? Math.sin(f / 6 + i) * 6 : 0;
              return (
                <div key={i} style={{position: 'absolute', left: 50 + col * 140, top: 880 + row * 190 + sag, display: 'flex', flexDirection: 'column', alignItems: 'center'}}>
                  <Person i={i} h={150} />
                </div>
              );
            })}
          </AbsoluteFill>
          {relief && <div style={{position: 'absolute', top: 230, width: '100%', textAlign: 'center', fontSize: 100}}>😮‍💨</div>}
          {f >= 290 && f < 350 && <div style={{position: 'absolute', top: 700, width: '100%', textAlign: 'center', color: '#fff', fontSize: 120, fontWeight: 900}}>… 🦗 …</div>}
        </Shake>
      )}
      {black && (
        <AbsoluteFill style={{alignItems: 'center', justifyContent: 'center', opacity: t}}>
          <div style={{color: '#ff2a3a', fontWeight: 900, fontSize: 120, textAlign: 'center', lineHeight: 1.1, textShadow: '0 0 40px #e11'}}>
            ZOMBIE<br />ATTACK:<br />ม.6/1
          </div>
          <div style={{color: '#e8ecf5', fontWeight: 700, fontSize: 48, textAlign: 'center', marginTop: 50, padding: '0 70px', lineHeight: 1.35}}>
            “หนีซอมบี้ว่ายากแล้ว หนีงานครูยากกว่า”
          </div>
        </AbsoluteFill>
      )}
      <Glitch on={(f >= 515 && f < 522) || (f >= 410 && f < 414)} />
      <Subs lines={lines} />
      <Sfx name="announce" at={146} />
      <Sfx name="boing" at={350} />
      <Sfx name="scream" at={410} vol={0.6} />
      <Sfx name="stinger" at={490} />
      <Sfx name="groan" at={535} />
      <Sfx name="giggle" at={565} />
    </AbsoluteFill>
  );
};
