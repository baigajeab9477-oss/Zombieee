import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {CHARS} from '../data';
import {Person, Tag} from '../components/Person';
import {Classroom, Shake, Glitch} from '../components/Fx';
import {Subs, Sfx, Line} from '../components/Media';

const lines: Line[] = [
  {id: 's1-pa', from: 130, to: 250, who: 'เสียงประกาศ', text: 'ประกาศ! ขณะนี้มีซอมบี้บุกโรงเรียน ขอให้นักเรียนทุกคนอยู่ในความสงบ'},
  {id: 's1-exam', from: 292, to: 358, who: 'นักเรียนคนหนึ่ง', text: 'ห้ะ! แล้ววันนี้มีสอบไหม?'},
];

export const Scene1: React.FC = () => {
  const f = useCurrentFrame();
  const frozen = f >= 250;
  const shake = f >= 250 && f < 290 ? 10 : f >= 130 && f < 250 ? 2 : 0;
  return (
    <AbsoluteFill>
      <Shake amp={shake}>
        <Classroom alert={f >= 130} />
        <div style={{position: 'absolute', top: 60, width: '100%', textAlign: 'center', color: '#fff'}}>
          <div style={{fontSize: 46, fontWeight: 900}}>ห้องสอนศึกษา ในพระอุปถัมภ์ฯ</div>
          <div style={{fontSize: 60, fontWeight: 900, color: '#ff4d5a'}}>ม.6/1 · 10:42 น.</div>
        </div>
        <div style={{position: 'absolute', top: 232, width: '100%', textAlign: 'center', color: '#cfe8dd', fontSize: 50, fontWeight: 700}}>
          {frozen ? '...' : 'วันเรียนธรรมดา'}
        </div>
        <div style={{position: 'absolute', left: 40, top: 360, width: 1000}}>
          {CHARS.map((c, i) => {
            const col = i % 4, row = Math.floor(i / 4);
            const bob = frozen ? 0 : Math.sin(f / 8 + i) * 3;
            const sleepy = i % 7 === 3, chat = i % 5 === 1, phone = i % 6 === 2;
            const emoji = frozen ? '😨' : sleepy ? '😴' : chat ? '💬' : phone ? '📱' : '';
            return (
              <div key={i} style={{position: 'absolute', left: col * 250, top: row * 170, width: 250, display: 'flex', flexDirection: 'column', alignItems: 'center'}}>
                <div style={{height: 34, fontSize: 30}}>{emoji}</div>
                <Person i={i} h={100} style={{transform: `translateY(${bob}px) rotate(${sleepy && !frozen ? 12 : 0}deg)`}} />
                <Tag name={c.name} />
              </div>
            );
          })}
        </div>
      </Shake>
      <Glitch on={(f >= 125 && f < 135) || (f >= 250 && f < 256)} />
      <Subs lines={lines} />
      <Sfx name="announce" at={125} />
      <Sfx name="hit" at={250} />
      <Sfx name="boing" at={292} />
    </AbsoluteFill>
  );
};
