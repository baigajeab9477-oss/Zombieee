import React from 'react';
import {AbsoluteFill, Sequence, useCurrentFrame, interpolate} from 'remotion';
import {Person} from '../components/Person';
import {Classroom, Shake, clamp} from '../components/Fx';
import {Subs, Sfx, Line} from '../components/Media';

const D = 78; // 5 ช็อต x 78 เฟรม = 390
const shots = [
  {e: '🧟', t: 'ซอมบี้บุกโรงเรียน!!', z: true, p: -1},
  {e: '🎒', t: 'ขอเก็บกระเป๋าก่อน เดี๋ยวงานหาย!', p: 3},
  {e: '⏰', t: 'เลิกเรียนหรือยังคะ...?', p: 10},
  {e: '🍪', t: 'ขอหยิบขนมก่อนนะ', p: 17},
  {e: '🏃', t: 'ทุกคนใจเย็นๆ !!!', p: 24, run: true},
];

const Shot: React.FC<{s: (typeof shots)[number]}> = ({s}) => {
  const f = useCurrentFrame();
  const bob = Math.sin(f / 2) * 10;
  const runX = interpolate(f, [0, D], [-300, 1350], clamp);
  return (
    <AbsoluteFill>
      <Classroom alert />
      {[0, 1, 2, 3, 4].map((j) => {
        const zh = 240 + f * (2 + (j % 2)) * 1.5 + (s.z ? 300 : 0);
        return (
          <div key={j} style={{position: 'absolute', left: 20 + j * 200, top: 1250 - zh}}>
            <Person i={j + 5} h={zh} zombie flip={j % 2 === 0} />
          </div>
        );
      })}
      {s.p >= 0 && (
        <>
          <div style={{position: 'absolute', left: s.run ? runX : 270, top: 620 + bob}}>
            <Person i={s.p} h={620} />
          </div>
          {s.run && [1, 2, 3].map((k) => (
            <div key={k} style={{position: 'absolute', left: runX - 330 * k, top: 900 + bob}}>
              <Person i={s.p - k} h={340} />
            </div>
          ))}
        </>
      )}
      <div style={{position: 'absolute', top: 380, width: '100%', textAlign: 'center', fontSize: 190, transform: `rotate(${Math.sin(f / 3) * 8}deg)`}}>{s.e}</div>
    </AbsoluteFill>
  );
};

export const Scene2: React.FC = () => {
  const lines: Line[] = shots.map((s, k) => ({id: `s2-${k + 1}`, from: k * D + 4, to: k * D + D - 2, text: s.t, who: k ? 'นักเรียนคนหนึ่ง' : undefined}));
  return (
    <AbsoluteFill>
      <Shake amp={6}>
        {shots.map((s, k) => (
          <Sequence key={k} from={k * D} durationInFrames={D}>
            <Shot s={s} />
          </Sequence>
        ))}
      </Shake>
      <Subs lines={lines} />
      <Sfx name="groan" at={0} />
      {shots.map((_, k) => <Sfx key={k} name="whoosh" at={k * D} vol={0.6} />)}
      <Sfx name="scream" at={D + 8} vol={0.5} />
      <Sfx name="boing" at={3 * D + 5} />
      <Sfx name="hit" at={4 * D} />
    </AbsoluteFill>
  );
};
