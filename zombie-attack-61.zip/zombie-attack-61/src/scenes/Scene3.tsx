import React from 'react';
import {AbsoluteFill, Sequence, spring, useCurrentFrame, useVideoConfig, interpolate} from 'remotion';
import {CHARS} from '../data';
import {Person} from '../components/Person';
import {Classroom, Glitch, clamp} from '../components/Fx';
import {Sfx} from '../components/Media';

const G = 107; // 7 กลุ่ม x 4 คน = 28 คน, 750 เฟรม (กลุ่มสุดท้าย 108)

const Card: React.FC<{i: number; k: number}> = ({i, k}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: Math.max(0, f - k * 10), fps, config: {damping: 11, mass: 0.7}});
  const out = interpolate(f, [96, 106], [1, 0], clamp);
  const c = CHARS[i];
  const col = k % 2, row = Math.floor(k / 2);
  return (
    <div style={{position: 'absolute', left: 40 + col * 510, top: 250 + row * 720, width: 490, height: 690, borderRadius: 28, background: 'linear-gradient(#141b2b,#0a0e18)', border: '4px solid #c1121f', boxShadow: '0 0 40px rgba(220,20,40,.45)', transform: `scale(${s}) rotate(${(1 - s) * -8}deg)`, opacity: out, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'space-between', padding: '22px 18px', boxSizing: 'border-box'}}>
      <div style={{alignSelf: 'flex-start', color: '#ff4d5a', fontWeight: 900, fontSize: 34}}>#{String(i + 1).padStart(2, '0')}</div>
      <Person i={i} h={320} />
      <div style={{color: '#fff', fontWeight: 900, fontSize: 74, textShadow: '0 0 20px #e11'}}>{c.name}</div>
      <div style={{color: '#cfd6e6', fontWeight: 700, fontSize: 30, textAlign: 'center', lineHeight: 1.3, minHeight: 80}}>{c.role}</div>
    </div>
  );
};

const Group: React.FC<{g: number}> = ({g}) => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill>
      <div style={{position: 'absolute', top: 70, width: '100%', textAlign: 'center', color: '#fff', fontSize: 62, fontWeight: 900}}>ทีมรอดชีวิต ม.6/1</div>
      <div style={{position: 'absolute', top: 160, width: '100%', textAlign: 'center', color: '#ff4d5a', fontSize: 40, fontWeight: 700}}>
        คนที่ {g * 4 + 1}–{g * 4 + 4} จาก 28
      </div>
      <div style={{position: 'absolute', top: 215, left: 40, right: 40, height: 14, background: '#222', borderRadius: 7}}>
        <div style={{width: `${((g * 4 + 4) / 28) * 100}%`, height: '100%', background: '#c1121f', borderRadius: 7}} />
      </div>
      {[0, 1, 2, 3].map((k) => <Card key={k} i={g * 4 + k} k={k} />)}
      <Glitch on={f < 4} />
      {[0, 1, 2, 3].map((k) => <Sfx key={k} name="pop" at={k * 10} vol={0.6} />)}
    </AbsoluteFill>
  );
};

export const Scene3: React.FC = () => (
  <AbsoluteFill>
    <Classroom alert />
    {Array.from({length: 7}, (_, g) => (
      <Sequence key={g} from={g * G} durationInFrames={g === 6 ? 108 : G}>
        <Group g={g} />
      </Sequence>
    ))}
  </AbsoluteFill>
);
