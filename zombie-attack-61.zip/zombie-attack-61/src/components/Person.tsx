import React from 'react';

const SKINS = ['#f1c9a5', '#e0ac82', '#c68c64', '#f5d6b8', '#d9a37a', '#b9805a'];
const HAIRS = ['#111', '#2a1a12', '#3b2a20', '#1a1a2e', '#4a2c1a', '#0d0d0d'];
const TIES = ['#c1121f', '#1f6feb', '#f2b705', '#2a9d8f', '#e76f51', '#8e44ad', '#ff7aa2'];

// ตัวการ์ตูนต่างกันทุกคน (ทรงผม/สีผิว/สีผม/สีผ้าพันคอ/อุปกรณ์) ตามเลข index
export const Person: React.FC<{i: number; h?: number; zombie?: boolean; flip?: boolean; style?: React.CSSProperties}> = ({i, h = 140, zombie, flip, style}) => {
  const skin = zombie ? '#7f9a86' : SKINS[i % SKINS.length];
  const hair = HAIRS[(i * 3) % HAIRS.length];
  const hs = i % 4;
  const acc = i % 7;
  const tie = TIES[(i * 5) % TIES.length];
  const pants = zombie ? '#2b2f3a' : '#1d2340';
  const top = 'M29 36 Q30 14 50 14 Q71 14 71 36 Q60 24 50 26 Q38 24 29 36Z';
  return (
    <svg viewBox="-12 0 124 140" height={h} width={(h * 124) / 140} style={{overflow: 'visible', transform: flip ? 'scaleX(-1)' : undefined, ...style}}>
      {hs === 1 && <rect x="26" y="22" width="48" height="56" rx="22" fill={hair} />}
      <rect x="34" y="98" width="13" height="38" rx="5" fill={pants} />
      <rect x="53" y="98" width="13" height="38" rx="5" fill={pants} />
      <rect x="28" y="60" width="44" height="46" rx="10" fill={zombie ? '#9aa3a8' : '#f4f4f4'} />
      {zombie ? (
        <>
          <rect x="-8" y="64" width="40" height="11" rx="5" fill={skin} />
          <rect x="68" y="64" width="40" height="11" rx="5" fill={skin} />
          <path d="M36 70 l10 12 l-4 10 l14 -6 l6 -14z" fill="#8b0a14" opacity=".8" />
        </>
      ) : (
        <>
          <rect x="18" y="64" width="12" height="36" rx="6" fill="#f4f4f4" />
          <rect x="70" y="64" width="12" height="36" rx="6" fill="#f4f4f4" />
          <path d="M50 62 l-8 10 l8 8 l8 -8z" fill={tie} />
        </>
      )}
      <circle cx="50" cy="38" r="21" fill={skin} />
      {hs === 3 ? <path d="M29 34 L33 12 L42 22 L50 8 L58 22 L67 12 L71 34 Q60 24 50 26 Q40 24 29 34Z" fill={hair} /> : <path d={top} fill={hair} />}
      {hs === 2 && <circle cx="50" cy="11" r="9" fill={hair} />}
      {acc === 3 && !zombie && <rect x="29" y="25" width="42" height="5" rx="2" fill="#ffd54a" />}
      {acc === 5 && !zombie && <><circle cx="38" cy="47" r="4" fill="#ff8aa0" opacity=".6" /><circle cx="62" cy="47" r="4" fill="#ff8aa0" opacity=".6" /></>}
      {acc === 6 && !zombie && <path d="M29 36 Q50 6 71 36" stroke="#444" strokeWidth="4" fill="none" />}
      {zombie ? (
        <>
          <circle cx="42" cy="40" r="4" fill="#ff1a2a" /><circle cx="58" cy="40" r="4" fill="#ff1a2a" />
          <ellipse cx="50" cy="52" rx="7" ry="5" fill="#3a0008" />
          <rect x="45" y="48" width="3" height="4" fill="#ddd" /><rect x="52" y="48" width="3" height="4" fill="#ddd" />
        </>
      ) : (
        <>
          <circle cx="42" cy="40" r="2.8" fill="#111" /><circle cx="58" cy="40" r="2.8" fill="#111" />
          <path d="M43 49 Q50 54 57 49" stroke="#5a2a20" strokeWidth="2" fill="none" strokeLinecap="round" />
        </>
      )}
      {acc === 1 && !zombie && <g stroke="#222" strokeWidth="2" fill="none"><circle cx="42" cy="40" r="6" /><circle cx="58" cy="40" r="6" /><path d="M48 40h4" /></g>}
      {acc === 4 && !zombie && <rect x="34" y="62" width="5" height="34" fill="#444" />}
      {acc === 2 && !zombie && <rect x="60" y="62" width="5" height="34" fill="#444" />}
    </svg>
  );
};

export const Tag: React.FC<{name: string; size?: number}> = ({name, size = 26}) => (
  <div style={{background: 'rgba(0,0,0,.7)', color: '#fff', fontWeight: 900, fontSize: size, padding: '0 12px', borderRadius: 10, border: '2px solid #c1121f', whiteSpace: 'nowrap'}}>{name}</div>
);
