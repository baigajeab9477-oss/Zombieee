import React from 'react';
import {AbsoluteFill, random, useCurrentFrame, interpolate} from 'remotion';
export const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

export const Shake: React.FC<{amp?: number; children: React.ReactNode}> = ({amp = 0, children}) => {
  const f = useCurrentFrame();
  const x = (random(`x${f}`) - 0.5) * amp * 2;
  const y = (random(`y${f}`) - 0.5) * amp * 2;
  const r = (random(`r${f}`) - 0.5) * amp * 0.08;
  return <AbsoluteFill style={{transform: `translate(${x}px,${y}px) rotate(${r}deg)`}}>{children}</AbsoluteFill>;
};

// Color grade: น้ำเงินเข้ม/เทา/ดำ/แดง
export const Grade: React.FC = () => (
  <AbsoluteFill style={{pointerEvents: 'none'}}>
    <AbsoluteFill style={{background: 'linear-gradient(180deg,rgba(10,20,55,.5),rgba(12,12,16,.4))', mixBlendMode: 'multiply'}} />
    <AbsoluteFill style={{background: 'radial-gradient(ellipse at center,transparent 45%,rgba(0,0,0,.85) 100%)'}} />
  </AbsoluteFill>
);

export const Grain: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill style={{opacity: 0.14, mixBlendMode: 'overlay', pointerEvents: 'none'}}>
      <svg width="100%" height="100%">
        <filter id="n"><feTurbulence type="fractalNoise" baseFrequency="0.8" numOctaves="2" seed={f % 7} /></filter>
        <rect width="100%" height="100%" filter="url(#n)" />
      </svg>
    </AbsoluteFill>
  );
};

export const Glitch: React.FC<{on: boolean}> = ({on}) => {
  const f = useCurrentFrame();
  if (!on) return null;
  return (
    <AbsoluteFill style={{pointerEvents: 'none'}}>
      {[0, 1, 2, 3, 4].map((i) => (
        <div
          key={i}
          style={{
            position: 'absolute', left: 0, right: 0,
            top: random(`gy${f}${i}`) * 1900,
            height: 10 + random(`gh${f}${i}`) * 90,
            transform: `translateX(${(random(`gx${f}${i}`) - 0.5) * 120}px)`,
            background: i % 2 ? 'rgba(255,0,60,.4)' : 'rgba(0,220,255,.35)',
            mixBlendMode: 'screen',
          }}
        />
      ))}
    </AbsoluteFill>
  );
};

export const Flash: React.FC<{at?: number; len?: number; color?: string}> = ({at = 0, len = 8, color = '#fff'}) => {
  const f = useCurrentFrame();
  const o = f < at ? 0 : interpolate(f, [at, at + len], [0.9, 0], clamp);
  return <AbsoluteFill style={{background: color, opacity: o, pointerEvents: 'none'}} />;
};

export const Classroom: React.FC<{alert?: boolean; calm?: boolean}> = ({alert, calm}) => {
  const f = useCurrentFrame();
  const pulse = alert ? ((Math.sin(f / 4) + 1) / 2) * 0.35 : 0;
  return (
    <AbsoluteFill style={{background: calm ? 'linear-gradient(#1a2a44,#0f1a2e 60%,#080c16)' : 'linear-gradient(#1c2433,#0f1522 60%,#0a0d14)'}}>
      <div style={{position: 'absolute', top: 210, left: 70, right: 70, height: 110, background: '#1d3a33', border: '10px solid #5b4630', borderRadius: 8}} />
      <div style={{position: 'absolute', left: 0, right: 0, bottom: 0, height: 620, background: 'repeating-linear-gradient(90deg,#141a26 0 120px,#0f1420 120px 240px)'}} />
      <AbsoluteFill style={{background: `rgba(220,20,40,${pulse})`, mixBlendMode: 'screen'}} />
    </AbsoluteFill>
  );
};
