import React from 'react';
import {Audio, Sequence, staticFile, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {FLAGS} from '../data';

export const Sfx: React.FC<{name: string; at?: number; vol?: number}> = ({name, at = 0, vol = 0.8}) =>
  FLAGS.audio ? (
    <Sequence from={at} layout="none">
      <Audio src={staticFile(`audio/${name}.wav`)} volume={vol} />
    </Sequence>
  ) : null;

export type Line = {id: string; from: number; to: number; text: string; who?: string; big?: boolean; color?: string};

const SubLine: React.FC<{l: Line}> = ({l}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: f, fps, config: {damping: 12}});
  return (
    <>
      {FLAGS.voice && <Audio src={staticFile(`voice/${l.id}.mp3`)} />}
      <div style={{position: 'absolute', left: 50, right: 50, bottom: 150, textAlign: 'center', transform: `scale(${0.8 + 0.2 * s})`, opacity: s}}>
        {l.who && (
          <div style={{display: 'inline-block', background: '#b3121f', color: '#fff', fontWeight: 900, fontSize: 34, padding: '4px 24px', borderRadius: 30, marginBottom: 12}}>{l.who}</div>
        )}
        <div style={{background: 'rgba(0,0,0,.65)', borderRadius: 24, padding: '18px 30px', color: l.color || '#fff', fontWeight: 900, fontSize: l.big ? 88 : 54, lineHeight: 1.3}}>{l.text}</div>
      </div>
    </>
  );
};

export const Subs: React.FC<{lines: Line[]}> = ({lines}) => (
  <>
    {lines.map((l) => (
      <Sequence key={l.id} from={l.from} durationInFrames={l.to - l.from}>
        <SubLine l={l} />
      </Sequence>
    ))}
  </>
);
