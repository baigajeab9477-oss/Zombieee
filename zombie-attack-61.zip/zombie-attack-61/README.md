# ZOMBIE ATTACK: ม.6/1 (Remotion, 1080x1920, 90 วินาที)

## ติดตั้ง
1. ติดตั้ง Node.js 18+ (https://nodejs.org)
2. `npm install`
3. (Linux เท่านั้น) `sudo apt install fonts-noto-color-emoji` เพื่อให้อีโมจิในวิดีโอแสดงผล
4. ต้องต่ออินเทอร์เน็ตตอน Render ครั้งแรก (โหลดฟอนต์ Kanit ภาษาไทยจาก Google Fonts)

## ดูตัวอย่าง / Render
- ดูตัวอย่าง: `npm start` (เปิด Remotion Studio เลือก composition "ZombieAttack")
- Render MP4: `npm run render` ได้ไฟล์ `out/zombie-attack.mp4`
- ถ้าเครื่องช้า: `npx remotion render ZombieAttack out/zombie-attack.mp4 --concurrency=2`

## เสียง
- BGM + SFX อยู่ใน `public/audio/*.wav` (สร้างให้แล้ว สร้างใหม่ได้ด้วย `npm run audio`)
  อยากใช้เพลงของตัวเอง: ทับไฟล์ `bgm.wav` หรือ ปิดทั้งหมดที่ `FLAGS.audio` ใน `src/data.ts`
- เสียงพากย์: อัดไฟล์ `.mp3` ตั้งชื่อตาม id ด้านล่าง วางใน `public/voice/` แล้วตั้ง `FLAGS.voice = true`
  - ซีน 1: s1-pa, s1-exam
  - ซีน 2: s2-1 ถึง s2-5
  - ซีน 4: s4-1 ถึง s4-6
  - ซีน 5: s5-1 ถึง s5-4
  ไฟล์เสียงพากย์จะเริ่มตรงกับเวลาขึ้นซับแต่ละบรรทัด ปรับเวลาได้ที่ `lines` ในแต่ละ Scene

## โครงสร้างเวลา (30fps, รวม 2700 เฟรม = 90 วินาที)
| ซีน | ไฟล์ | วินาที |
|---|---|---|
| 1 วันธรรมดา | scenes/Scene1.tsx | 0–12 |
| 2 ซอมบี้บุก | scenes/Scene2.tsx | 12–25 |
| 3 ทีมรอดชีวิต (28 คน 7 กลุ่ม) | scenes/Scene3.tsx | 25–50 |
| 4 หนีครั้งใหญ่ | scenes/Scene4.tsx | 50–70 |
| 5 หักมุมตอนจบ | scenes/Scene5.tsx | 70–90 |

## ตัวละคร
ชื่อ/มุกทั้ง 28 คนอยู่ที่ `src/data.ts` (ถ้าจำนวนไม่ครบ 28 โปรเจกต์จะแจ้ง error ทันที)
ทุกคนมีชื่อขึ้นจอในซีน 1 (ป้ายชื่อ) และซีน 3 (การ์ดแนะนำตัว)
หน้าตาตัวการ์ตูนแต่ละคนต่างกัน กำหนดใน `components/Person.tsx` ถ้ามีรูปจริงให้เปลี่ยน `<Person>` เป็น `<Img src={staticFile(...)}>`
