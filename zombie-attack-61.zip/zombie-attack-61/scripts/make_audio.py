# สร้าง BGM + SFX เป็นไฟล์ .wav ด้วย Python ล้วน (ไม่ต้องติดตั้งอะไรเพิ่ม)
import math, random, struct, wave, os
SR = 22050
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'public', 'audio')
os.makedirs(OUT, exist_ok=True)
random.seed(7)
TAU = 2 * math.pi

def save(name, s, gain=0.9):
    m = max(1e-9, max(abs(x) for x in s))
    with wave.open(os.path.join(OUT, name + '.wav'), 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes(b''.join(struct.pack('<h', int(max(-1, min(1, x / m * gain)) * 32767)) for x in s))

def gen(dur, fn):
    return [fn(i / SR) for i in range(int(dur * SR))]

def sweep(dur, f_of_t, shape, env):
    out, ph = [], 0.0
    for i in range(int(dur * SR)):
        t = i / SR
        ph += TAU * f_of_t(t) / SR
        out.append(shape(ph) * env(t))
    return out

sine = math.sin
saw = lambda p: 2 * ((p / TAU) % 1) - 1
mix = lambda p: 0.6 * saw(p) + 0.4 * sine(p)
ex = math.exp

# ประกาศ ดิง-ด่อง
def ann(t):
    if t < 0.6: f, e = 880, ex(-5 * t)
    else: f, e = 660, ex(-4 * (t - 0.6))
    tt = t if t < 0.6 else t - 0.6
    return (sine(TAU * f * tt) + 0.3 * sine(TAU * 2 * f * tt)) * e * (1 if t < 1.5 else 0)
save('announce', gen(1.5, ann))

# whoosh
lp = 0.0; w = []
for i in range(int(0.6 * SR)):
    t = i / SR; lp += (random.uniform(-1, 1) - lp) * (0.05 + 0.5 * t)
    w.append(lp * math.sin(math.pi * t / 0.6) ** 2)
save('whoosh', w)

save('hit', sweep(0.5, lambda t: 140 * ex(-t * 9) + 40, sine, lambda t: ex(-t * 7)))
save('groan', [a + 0.15 * random.uniform(-1, 1) * math.sin(math.pi * i / (1.6 * SR)) for i, a in enumerate(
    sweep(1.6, lambda t: 95 + 8 * sine(TAU * 5 * t) - 22 * t, mix, lambda t: math.sin(math.pi * t / 1.6)))])
save('boing', sweep(0.7, lambda t: 220 + 520 * ex(-t * 5) * (1 + 0.3 * sine(TAU * 28 * t)), sine, lambda t: ex(-t * 3.5)))
save('pop', sweep(0.12, lambda t: 500 + 3000 * t, sine, lambda t: ex(-t * 30)))
save('scream', sweep(0.9, lambda t: 800 + 500 * sine(TAU * 7 * t) + 400 * t, mix, lambda t: math.sin(math.pi * t / 0.9) ** 0.6))

# womp womp (ทรอมโบนเศร้า)
notes = [(392, 0.4), (370, 0.4), (349, 0.4), (311, 1.0)]
womp = []
for f0, d in notes:
    womp += sweep(d, lambda t, f0=f0: f0 * (1 - 0.03 * sine(TAU * 6 * t)) - (30 * t if d > 0.9 else 0), mix, lambda t, d=d: min(1, t * 30) * ex(-t * (1.5 if d < 0.9 else 1.2)))
save('womp', womp)

# stinger
def sting(t):
    s = sum((((f * t) % 1) * 2 - 1) for f in (110, 116.5, 164.8, 220.5)) / 4
    return s * ex(-t * 2.2) + sine(TAU * 55 * t) * ex(-t * 6)
save('stinger', gen(2.2, sting))

# หัวเราะคิก
g = []
for k in range(5):
    g += sweep(0.13, lambda t, k=k: 380 + 40 * k + 120 * t, sine, lambda t: math.sin(math.pi * t / 0.13))
    g += [0.0] * int(0.07 * SR)
save('giggle', g)

# glitch
v = 0; gl = []
for i in range(int(0.25 * SR)):
    if i % 25 == 0: v = random.choice([-1, 1]) * random.random()
    gl.append(v * (1 - i / (0.25 * SR)))
save('glitch', gl, 0.6)

# BGM 90 วินาที: drone มืด + จังหวะหัวใจเร่งขึ้น
dur = 90; n = dur * SR; bgm = []
for i in range(n):
    t = i / SR
    d = 0.5 * sine(TAU * 55 * t) + 0.4 * sine(TAU * 55.7 * t) + 0.2 * sine(TAU * 82.4 * t) * (0.5 + 0.5 * sine(TAU * t / 12))
    d += 0.08 * sine(TAU * 220 * t) * max(0, sine(TAU * t / 20))
    period = 1.0 if t < 12 else (0.7 if t < 50 else 0.5)
    ph = t % period
    beat = sine(TAU * 58 * ph) * ex(-ph * 14) + 0.7 * sine(TAU * 52 * (ph - 0.2)) * ex(-(ph - 0.2) * 14) * (ph > 0.2)
    bgm.append(d * 0.6 + beat * (0.5 if t > 12 else 0.2))
save('bgm', bgm, 0.8)
print('สร้างไฟล์เสียงที่', os.path.abspath(OUT))
